
  # Inventario de artículos

  This is a code bundle for Inventario de artículos. The original project is available at https://www.figma.com/design/c2nFns7wXHmb4G610zPxTT/Inventario-de-art%C3%ADculos.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  