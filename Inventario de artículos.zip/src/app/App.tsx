import { useState } from 'react';
import { Laptop, Monitor, Cable, Keyboard, Smartphone, HardDrive, Headphones, Mouse, Usb, X, Plus, Trash2, HelpCircle } from 'lucide-react';

interface Model {
  id: string;
  name: string;
  serialNumber: string;
}

interface InventoryItem {
  id: number;
  name: string;
  icon: any;
  models: Model[];
  hasModels: boolean;
}

export default function App() {
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>([
    {
      id: 1,
      name: 'Laptop',
      icon: Laptop,
      hasModels: true,
      models: []
    },
    {
      id: 2,
      name: 'Monitor',
      icon: Monitor,
      hasModels: true,
      models: []
    },
    {
      id: 3,
      name: 'Cargador de laptop',
      icon: Cable,
      hasModels: true,
      models: []
    },
    {
      id: 4,
      name: 'Teclado',
      icon: Keyboard,
      hasModels: true,
      models: []
    },
    {
      id: 5,
      name: 'Celular',
      icon: Smartphone,
      hasModels: true,
      models: []
    },
    {
      id: 6,
      name: 'Gabinete',
      icon: HardDrive,
      hasModels: true,
      models: []
    },
    {
      id: 7,
      name: 'Cargador de Celular',
      icon: Cable,
      hasModels: true,
      models: []
    },
    {
      id: 8,
      name: 'Audífonos',
      icon: Headphones,
      hasModels: true,
      models: []
    },
    {
      id: 9,
      name: 'Mouse',
      icon: Mouse,
      hasModels: true,
      models: []
    },
    {
      id: 10,
      name: 'USB',
      icon: Usb,
      hasModels: true,
      models: []
    },
    {
      id: 11,
      name: 'Otros',
      icon: HelpCircle,
      hasModels: true,
      models: []
    }
  ]);

  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [newModelName, setNewModelName] = useState('');
  const [newModelSerial, setNewModelSerial] = useState('');

  const handleItemClick = (item: InventoryItem) => {
    if (item.hasModels) {
      setSelectedItem(item);
    }
  };

  const handleAddModel = () => {
    if (!selectedItem || !newModelName.trim() || !newModelSerial.trim()) return;

    const newModel: Model = {
      id: Date.now().toString(),
      name: newModelName.trim(),
      serialNumber: newModelSerial.trim()
    };

    setInventoryItems(items =>
      items.map(item =>
        item.id === selectedItem.id
          ? { ...item, models: [...item.models, newModel] }
          : item
      )
    );

    setSelectedItem(prev =>
      prev ? { ...prev, models: [...prev.models, newModel] } : null
    );

    setNewModelName('');
    setNewModelSerial('');
  };

  const handleDeleteModel = (modelId: string) => {
    if (!selectedItem) return;

    setInventoryItems(items =>
      items.map(item =>
        item.id === selectedItem.id
          ? { ...item, models: item.models.filter(m => m.id !== modelId) }
          : item
      )
    );

    setSelectedItem(prev =>
      prev ? { ...prev, models: prev.models.filter(m => m.id !== modelId) } : null
    );
  };

  return (
    <div className="size-full flex items-center justify-center bg-gray-50 p-8">
      <div className="w-full max-w-4xl bg-white rounded-lg shadow-lg p-8">
        <h1 className="mb-8 text-center">Inventario de Equipo</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {inventoryItems.map((item) => {
            const Icon = item.icon;
            const isEmpty = item.models.length === 0;
            return (
              <div
                key={item.id}
                onClick={() => handleItemClick(item)}
                className={`flex items-center gap-4 p-4 border rounded-lg transition-all relative cursor-pointer hover:shadow-md ${
                  isEmpty
                    ? 'border-red-300 bg-red-50 hover:border-red-400'
                    : 'border-gray-200 hover:border-blue-400'
                }`}
              >
                <div className={`flex-shrink-0 w-12 h-12 rounded-lg flex items-center justify-center ${
                  isEmpty ? 'bg-red-100' : 'bg-blue-100'
                }`}>
                  <Icon className={`w-6 h-6 ${isEmpty ? 'text-red-600' : 'text-blue-600'}`} />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-gray-900">{item.name}</h3>
                  <p className={`text-sm ${isEmpty ? 'text-red-600 font-medium' : 'text-gray-500'}`}>
                    Cantidad: {item.models.length}
                  </p>
                </div>
                {item.hasModels && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleItemClick(item);
                    }}
                    className={`flex-shrink-0 w-8 h-8 text-white rounded-full flex items-center justify-center transition-colors shadow-md ${
                      isEmpty
                        ? 'bg-red-600 hover:bg-red-700'
                        : 'bg-blue-600 hover:bg-blue-700'
                    }`}
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {selectedItem && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            <div className="flex items-center justify-between p-6 border-b">
              <h2 className="font-semibold text-gray-900">
                Modelos de {selectedItem.name}
              </h2>
              <button
                onClick={() => setSelectedItem(null)}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6">
              <div className="space-y-3 mb-6">
                {selectedItem.models.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">
                    No hay modelos registrados. Agrega uno abajo.
                  </p>
                ) : (
                  selectedItem.models.map((model) => (
                    <div
                      key={model.id}
                      className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200"
                    >
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900">{model.name}</h4>
                        <p className="text-sm text-gray-500">S/N: {model.serialNumber}</p>
                      </div>
                      <button
                        onClick={() => handleDeleteModel(model.id)}
                        className="text-red-500 hover:text-red-700 transition-colors p-2"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  ))
                )}
              </div>

              <div className="border-t pt-6">
                <h3 className="font-medium text-gray-900 mb-4">Agregar Nuevo Modelo</h3>
                <div className="space-y-3">
                  <input
                    type="text"
                    placeholder="Nombre del modelo"
                    value={newModelName}
                    onChange={(e) => setNewModelName(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <input
                    type="text"
                    placeholder="Número de serie"
                    value={newModelSerial}
                    onChange={(e) => setNewModelSerial(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <button
                    onClick={handleAddModel}
                    disabled={!newModelName.trim() || !newModelSerial.trim()}
                    className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                  >
                    <Plus className="w-5 h-5" />
                    Agregar Modelo
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}